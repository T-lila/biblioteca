<?php
	define('HOST', 'localhost');
	define('USER', 'root');
	define('PASS', '');
	define('BASE', '3132m');

	$conn = new MySQLi(HOST, USER, PASS, BASE);

	